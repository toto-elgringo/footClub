<!DOCTYPE html>
<link rel="stylesheet" href="../css/style.css">

<footer>
    <p>© 2025 FootClub. Tous droits réservés.</p>
</footer>